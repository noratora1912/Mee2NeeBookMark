import json
import csv
import os
import re
from datetime import datetime, timezone, timedelta
import tkinter as tk
from tkinter import filedialog

def get_now_jst():
    return datetime.now(timezone(timedelta(hours=9)))

def select_lst_file():
    root = tk.Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(
        title="お気に入り.lstを選択してください",
        filetypes=[("List files", "*.lst"), ("All files", "*.*")]
    )
    return file_path

def parse_lst_file(lst_path):
    folders = []
    base_time = get_now_jst()

    with open(lst_path, 'r', encoding='CP932') as f:
        reader = csv.reader(f)

        for idx, row in enumerate(reader):
            if not row or not row[0]:
                continue

            path_raw = row[0].strip('"')

            # ドライブレター付きパス（例："E:\..."）を判定
            if not re.match(r"^[A-Za-z]:\\", path_raw):
                continue

            entry_dt = base_time + timedelta(seconds=idx)
            entry_iso = entry_dt.isoformat()

            folders.append({
                "Path": path_raw,
                "Name": None,
                "EntryTime": entry_iso,
                "Children": None
            })
    return folders

def build_bookmark_json(folders):
    return {
        "Format": "NeeView.Bookmark/43.3.3771",
        "Nodes": {
            "Name": None,
            "Path": None,
            "EntryTime": "0001-01-01T00:00:00",
            "Children": folders
        },
        "Books": [
            {
                "Path": folder["Path"],
                "Page": "",
                "PageMode": "SinglePage",
                "BookReadOrder": "RightToLeft",
                "IsSupportedDividePage": False,
                "IsSupportedSingleFirstPage": False,
                "IsSupportedSingleLastPage": False,
                "IsSupportedWidePage": True,
                "IsRecursiveFolder": True,
                "SortMode": "FileName",
                "AutoRotate": "None",
                "BaseScale": 1
            } for folder in folders
        ],
        "QuickAccess": { "Items": [] }
    }

def main():
    lst_path = select_lst_file()
    if not lst_path:
        print("⚠ ファイルが選択されませんでした。処理を中止します。")
        return

    folders = parse_lst_file(lst_path)
    if not folders:
        print("⚠ 有効なフォルダパスが見つかりませんでした。")
        return

    bookmark_json = build_bookmark_json(folders)
    out_path = os.path.join(os.path.dirname(lst_path), "bookmark.json")

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(bookmark_json, f, indent=2, ensure_ascii=False)

    print(f"✅ 変換完了: {out_path}")

if __name__ == "__main__":
    main()
